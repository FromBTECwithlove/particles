
startColor=color,startColorVar=color,texture=image,gravity=vector



vector
color
image
boolean
number


ui=[color startColor=color,startColorVar=color,endColor=color,endColorVar=color]:[position pos=vector,posVar=vector]
ui=all


index.html?ui=



	pjs.ui.buildUi(uiParamString, 'uiRoot');

