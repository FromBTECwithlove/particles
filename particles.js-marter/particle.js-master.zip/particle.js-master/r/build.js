({
    baseUrl: "../public/javascripts",
    name: "main",
    out: "../public/pjs-min.js"
})
